//
//  FourthTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

protocol fourthNavigationDelegate {
    func didTapCollectionViewCell(indexPath:IndexPath, title: String)
}

class FourthTableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let data = HomeData(name: ["Raag", "Lofi Beats", "Jazz Station", "Ease Anxiety & Stress", "Become Self-Aware", "Spiritual Mantra"], title: ["5 songs • 50 XP", "8 songs • 80 XP", "2 songs • 20 XP", "24 songs • 180 XP", "5 songs • 50 XP", "8 songs • 30 XP"])
    
    var image = ImageData(ImgName: ["CollectionViewImg(1)", "CollectionViewImg(1)", "CollectionViewImg(1)", "CollectionViewImg(1)", "CollectionViewImg(1)", "CollectionViewImg(1)"])
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var delegate: fourthNavigationDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "MusicPlaylistCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "MusicPlaylistCollectionViewCell")
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.name.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MusicPlaylistCollectionViewCell", for: indexPath)as! MusicPlaylistCollectionViewCell
        cell.nameLbl.text = data.name[indexPath.row]
        cell.titleLbl.text = data.title[indexPath.row]
        let image = image.ImgName[indexPath.row]
        cell.imageIcon.image = UIImage(named: image)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let title = "\(data.name[indexPath.row])"
        delegate?.didTapCollectionViewCell(indexPath: indexPath, title: title)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
