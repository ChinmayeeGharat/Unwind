//
//  MusicPlaylistCollectionViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

class MusicPlaylistCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageIcon: UIImageView!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var mainView: UIView!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imageIcon.layer.cornerRadius = 20
        backView.roundCorners(corners: [.bottomLeft, .bottomRight], radius: 20)
    }
}
