//
//  NestedTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

class NestedTableViewCell: UITableViewCell {

    @IBOutlet weak var IconImage: UIImageView!
    @IBOutlet weak var favoriteBtn: UIButton!
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    
    var  isFavorite: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        IconImage.layer.cornerRadius = 10
    }

    @IBAction func favoriteBtnTapped(_ sender: UIButton) {
        if isFavorite == false{
            favoriteBtn.setBackgroundImage(UIImage(named: "favoriteSelected"), for: .normal)
            isFavorite = true
        }else{
            favoriteBtn.setBackgroundImage(UIImage(named: "favorite"), for: .normal)
            isFavorite = false
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
