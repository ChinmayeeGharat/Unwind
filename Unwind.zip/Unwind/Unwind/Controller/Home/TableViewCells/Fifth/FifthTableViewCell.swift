//
//  FifthTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

protocol fifthNavigationDelegate {
    func didTapCollectionViewCell(indexPath:IndexPath, title: String)
}

class FifthTableViewCell: UITableViewCell, UITableViewDelegate, UITableViewDataSource {
    
    var data  = HomeData(name: ["Connect Mind + Body","Alpha Waves","Binaural Beats", "Focus Temple","Ambience for Focus","Settling Thoughts","Destiny","City Night","Rain and Thunder","Feel the Nature","Feel the Silence","Walking on Piano","Mind Waves"], title: ["9 mins • 10 XP","10 mins • 10 XP","11 mins • 10 XP","14 mins • 10 XP","12 mins • 10 XP","12 mins • 10 XP","15 mins • 10 XP","30 mins • 10 XP","18 mins • 10 XP","18 mins • 10 XP","10 mins • 10 XP","10 mins • 10 XP","10 mins • 10 XP"])
    
    var Image = ImageData(ImgName: ["TableviewImg","TableviewImg(1)", "TableviewImg(2)","TableviewImg(3)"])
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var background: UIView!
    @IBOutlet weak var musicIcon: UIImageView!
    
    var delegate: secondNavigationDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "NestedTableViewCell", bundle: nil), forCellReuseIdentifier: "NestedTableViewCell")
        
        background.layer.cornerRadius = 20
        musicIcon.layer.cornerRadius = 10
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NestedTableViewCell", for: indexPath)as! NestedTableViewCell
        cell.nameLbl.text = data.name[indexPath.row]
        cell.titleLbl.text = data.title[indexPath.row]
        let image = Image.ImgName[indexPath.row]
        cell.IconImage.image = UIImage(named: image)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = "For Focus"
        delegate?.didTapCollectionViewCell(indexPath: indexPath, title: title)
    }
    
    @IBAction func seeAllTapped(_ sender: UIButton) {
        let title = "For Focus"
        delegate?.didTapCollectionViewCell(indexPath: IndexPath(), title: title)
    }
    
    @IBAction func playBtnTapped(_ sender: UIButton) {
        let title = "For Focus"
        delegate?.didTapCollectionViewCell(indexPath: IndexPath(), title: title)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
