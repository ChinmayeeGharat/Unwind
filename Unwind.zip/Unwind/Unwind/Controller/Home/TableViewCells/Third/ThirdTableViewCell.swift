//
//  ThirdTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

protocol thirdNavigationDelegate {
    func didTapCollectionViewCell(indexPath:IndexPath, title: String)
}

class ThirdTableViewCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate {
    
    let data = HomeData(name: ["Raag for Deep Sleep", "Om Chanting", "Om Chanting"], title: ["30 mins • 10 XP","45 mins • 10 XP",  "30 mins • 10 XP"])
    let image = ImageData(ImgName: ["image","omImg","omImg"])
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var pageController: UIPageControl!
    
    var currentPage: Int = 0
    var delegate: thirdNavigationDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UINib(nibName: "ThirdCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "ThirdCollectionViewCell")
        
        pageController.numberOfPages = data.name.count
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.name.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ThirdCollectionViewCell", for: indexPath)as! ThirdCollectionViewCell
        let image = image.ImgName[indexPath.row]
        cell.image.image = UIImage(named: image)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        pageController.currentPage = indexPath.row
        currentPage = indexPath.row
        nameLbl.text = data.name[currentPage]
        titleLbl.text = data.title[currentPage]
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let title = nameLbl.text
        delegate?.didTapCollectionViewCell(indexPath: indexPath, title: title!)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
