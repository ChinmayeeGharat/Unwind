//
//  ThirdCollectionViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 07/07/24.
//

import UIKit

class ThirdCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var image: UIImageView!
        
    override func awakeFromNib() {
        super.awakeFromNib()
        image.layer.cornerRadius = 20
    }

}
