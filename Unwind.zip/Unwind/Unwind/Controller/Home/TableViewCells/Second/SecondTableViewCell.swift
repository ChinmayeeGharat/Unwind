//
//  SecondTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

protocol secondNavigationDelegate {
    func didTapCollectionViewCell(indexPath:IndexPath, title: String)
}

class SecondTableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
    
    var data =  HomeData(name: ["Ease Anxiety & Stress", "For Creativity", "For  Focus"], title: ["42 songs • 370 XP", "12 songs • 100 XP", "65 songs • 100 XP"])
    
    var image = ImageData(ImgName: ["CollectionViewImg(1)", "CollectionViewImg(1)", "CollectionViewImg(1)"])
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var delegate: secondNavigationDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "SecondCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "SecondCollectionViewCell")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.name.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SecondCollectionViewCell", for: indexPath)as! SecondCollectionViewCell
        cell.nameLbl.text = data.name[indexPath.row]
        cell.titleLbl.text = data.title[indexPath.row]
        let image = image.ImgName[indexPath.row]
        cell.imageView.image = UIImage(named: image)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let title = "\(data.name[indexPath.row])"
        delegate?.didTapCollectionViewCell(indexPath: indexPath, title: title)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
