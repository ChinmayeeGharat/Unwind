//
//  SecondCollectionViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

class SecondCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imageView.roundCorners(corners: [.topLeft, .topRight], radius: 20)
    }
}
