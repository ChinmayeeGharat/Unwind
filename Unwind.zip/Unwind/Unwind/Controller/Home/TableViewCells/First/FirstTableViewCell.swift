//
//  FirstTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

class FirstTableViewCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
        textField.layer.cornerRadius  = textField.frame.height/2
        button1.layer.cornerRadius  = button1.frame.height/2
        button2.layer.cornerRadius  = button2.frame.height/2
        button3.layer.cornerRadius  = button3.frame.height/2
        button4.layer.cornerRadius  = button4.frame.height/2
        
//        this will dismiss the keyboard
//        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
//        view.addGestureRecognizer(tapGesture)
    }

//    @objc func dismissKeyboard() {
//        view.endEditing(true)
//    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
