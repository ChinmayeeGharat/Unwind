//
//  ListViewController.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

class ListViewController: UIViewController, BottomNavigationDelegate {
        
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var navigationName: UIBarButtonItem!
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var favoriteBtn: UIBarButtonItem!
    
    var name: String?
    var  isFavorite: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate =  self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "TopTableViewCell", bundle: nil), forCellReuseIdentifier: "TopTableViewCell")
        tableView.register(UINib(nibName: "BottomTableViewCell", bundle: nil), forCellReuseIdentifier: "BottomTableViewCell")
        tableView.showsVerticalScrollIndicator = false
        
        self.navigationName.title = name
        navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationBar.shadowImage = UIImage()
        navigationBar.isTranslucent = true
    }

    @IBAction func favoriteTapped(_ sender: UIBarButtonItem) {
        if isFavorite == false{
            self.favoriteBtn.tintColor = UIColor(named: "Pink")
            self.isFavorite = true
        }else{
            favoriteBtn.tintColor = .white
            isFavorite = false
        }
    }
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }
    
    //    Function to navigate from List ViewController to Player ViewController
    func didTapCollectionViewCell(indexPath: IndexPath, title: String) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let nextViewController = storyboard.instantiateViewController(withIdentifier: "PlayerViewController")as? PlayerViewController{
            nextViewController.name = title
            navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
}


// MARK: Tableview Delegate
extension ListViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch indexPath.row{
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TopTableViewCell", for: indexPath)
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "BottomTableViewCell", for: indexPath) as! BottomTableViewCell
            cell.delegate = self
            return cell
        default:
            fatalError("Unexpected row index")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.row{
        case 0:
            return 220
        case 1:
            return 1600
        default:
            return UITableView.automaticDimension
        }
    }
}

