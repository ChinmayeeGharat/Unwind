//
//  TopTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

protocol TopNavigationDelegate {
    func didTapCollectionViewCell(indexPath:IndexPath, title: String)
}

class TopTableViewCell: UITableViewCell {
    
    var delegate: TopNavigationDelegate?
    var name: String?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
    }
    
    @IBAction func PlayBtnTapped(_ sender: UIButton) {
        delegate?.didTapCollectionViewCell(indexPath: IndexPath(), title: name!)
}
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
