//
//  BottomTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

protocol BottomNavigationDelegate {
    func didTapCollectionViewCell(indexPath:IndexPath, title: String)
}

class BottomTableViewCell: UITableViewCell, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var delegate: BottomNavigationDelegate?
    
    var data  = HomeData(name: ["Connect Mind + Body","Alpha Waves","Binaural Beats", "Focus Temple","Ambience for Focus","Settling Thoughts","Destiny","City Night","Rain and Thunder","Feel the Nature","Feel the Silence","Walking on Piano","Mind Waves"], title: ["9 mins • 10 XP","10 mins • 10 XP","11 mins • 10 XP","14 mins • 10 XP","12 mins • 10 XP","12 mins • 10 XP","15 mins • 10 XP","30 mins • 10 XP","18 mins • 10 XP","18 mins • 10 XP","10 mins • 10 XP","10 mins • 10 XP","10 mins • 10 XP"])
    
    var image = ImageData(ImgName: ["TableviewImg","TableviewImg(1)", "TableviewImg(2)","TableviewImg(3)", "TableviewImg","TableviewImg(1)", "TableviewImg(2)","TableviewImg(3)","TableviewImg","TableviewImg(1)", "TableviewImg(2)","TableviewImg(3)","TableviewImg","TableviewImg(1)", "TableviewImg(2)","TableviewImg(3)"])
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.selectionStyle = .none
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UINib(nibName: "NestedBottomTableViewCell", bundle: nil), forCellReuseIdentifier: "NestedBottomTableViewCell")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.name.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NestedBottomTableViewCell", for: indexPath)as! NestedBottomTableViewCell
        cell.nameLbl.text = data.name[indexPath.row]
        cell.titleLbl.text = data.title[indexPath.row]
        let image = image.ImgName[indexPath.row]
        cell.imageIcon.image = UIImage(named: image)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = "\(data.name[indexPath.row])"
        delegate?.didTapCollectionViewCell(indexPath: indexPath, title: title)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
