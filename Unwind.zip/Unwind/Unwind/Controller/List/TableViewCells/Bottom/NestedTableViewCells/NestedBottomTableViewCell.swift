//
//  NestedBottomTableViewCell.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 06/07/24.
//

import UIKit

class NestedBottomTableViewCell: UITableViewCell {

    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var favoriteBtn: UIButton!
    @IBOutlet weak var imageIcon: UIImageView!
    
    var  isFavorite: Bool = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        backView.layer.cornerRadius = 20
        imageIcon.roundCorners(corners: [.topLeft, .bottomLeft], radius: 20)
    }

    @IBAction func favoriteBtnTapped(_ sender: UIButton) {
        if isFavorite == false{
            favoriteBtn.setBackgroundImage(UIImage(named: "favoriteSelected"), for: .normal)
            isFavorite = true
        }else{
            favoriteBtn.setBackgroundImage(UIImage(named: "favorite"), for: .normal)
            isFavorite = false
        }
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
