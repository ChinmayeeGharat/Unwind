//
//  PlayerViewController.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 07/07/24.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {

    @IBOutlet weak var progressBar: UIProgressView!
    @IBOutlet weak var playPauseBtn: UIButton!
    @IBOutlet weak var timeStartLbl: UILabel!
    @IBOutlet weak var navigationBar: UINavigationBar!
    @IBOutlet weak var favoriteBtn: UIButton!
    @IBOutlet weak var nameLbl: UILabel!
    
    var player: AVPlayer?
    var playerItem: AVPlayerItem?
    
    var timer: Timer?
    var totalTime: TimeInterval = 11 * 60 + 10
    var elapsedTime: TimeInterval = 0
    var isPaused: Bool = false
    
    var  isFavorite: Bool = false
    
    var name: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationBar.shadowImage = UIImage()
        navigationBar.isTranslucent = true
        
        guard let url = URL(string: "https://v3.cdn.level.game/raag-pilu-mix-full-vers.mp3") else { return }
        let playerItem = AVPlayerItem(url: url)
        player = AVPlayer(playerItem: playerItem)
        player?.play()
        startProgressBar()
        isPaused = false
        
        nameLbl.text = name
    }
  
    @IBAction func PlayPauseBtnTapped(_ sender: UIButton) {
        if player?.rate == 0 {
            player?.play()
            playPauseBtn.setBackgroundImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
            isPaused = false
        } else {
            player?.pause()
            playPauseBtn.setBackgroundImage(UIImage(systemName: "play.circle.fill"), for: .normal)
            isPaused = true
        }
    }
    
    @IBAction func favoriteBtnTapped(_ sender: UIButton) {
        if isFavorite == false{
            favoriteBtn.setBackgroundImage(UIImage(named: "favoriteSelected"), for: .normal)
            isFavorite = true
        }else{
            favoriteBtn.setBackgroundImage(UIImage(named: "favorite"), for: .normal)
            isFavorite = false
        }
    }
    
    @IBAction func backBtnTapped(_ sender: UIBarButtonItem) {
        player?.pause()
        playPauseBtn.setBackgroundImage(UIImage(systemName: "play.circle.fill"), for: .normal)
        isPaused = true
        navigationController?.popViewController(animated: true)
    }
    
    func startProgressBar() {
        player?.play()
        progressBar.progressTintColor = UIColor(named: "Medium Purple")
        progressBar.progress = 0.0
        timeStartLbl.text = formatTime(elapsedTime)
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateProgress), userInfo: nil, repeats: true)
    }
    
    @objc func updateProgress() {
        if !isPaused {
            if elapsedTime < totalTime {
                elapsedTime += 1
                progressBar.progress = Float(elapsedTime / totalTime)
                timeStartLbl.text = formatTime(elapsedTime)
            } else {
                timer?.invalidate()
                timer = nil
            }
        }
    }
    
    func formatTime(_ seconds: TimeInterval) -> String {
        let minutes = Int(seconds) / 60
        let seconds = Int(seconds) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
}
