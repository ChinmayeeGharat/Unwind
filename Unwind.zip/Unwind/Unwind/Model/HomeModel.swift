//
//  HomeModel.swift
//  Unwind
//
//  Created by Chinmayee Gharat on 07/07/24.
//

import Foundation

struct HomeData{
    let name: [String]
    let title: [String]
}

struct ImageData{
    let ImgName: [String]
}
